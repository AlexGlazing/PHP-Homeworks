<?php
//1 задание 
$iteration = 0;

while ($iteration <= 100) {
  if($iteration % 3 ==0){
    echo "$iteration\n";
  }
  $iteration++;
}